import torch
import torch.nn as nn
import numpy as np
from .common import *
# Attention gate代码
class AttentionBlock(nn.Module):
    def __init__(self, F_g, F_l, F_int):
        super(AttentionBlock, self).__init__()
        self.W_g = nn.Sequential(
            nn.Conv2d(F_g, F_int, kernel_size=1, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(F_int),
            nn.Sigmoid()
        )
        self.W_x = nn.Sequential(
            nn.Conv2d(F_l, F_int, kernel_size=1, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(F_int),
            nn.Sigmoid()
        )
        self.psi = nn.Sequential(
            nn.Conv2d(F_int, 1, kernel_size=1, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(1),
            nn.Sigmoid()
        )

        self.relu = nn.ReLU(inplace=True)

    def forward(self, g, x):
        g = self.W_g(g)
        x = self.W_x(x)

        psi = self.relu(g + x)
        psi = self.psi(psi)

        return x * psi


# AttentionUnet代码
class AttentionUnet(nn.Module):
    def __init__(self, num_input_channels=2, num_output_channels=3, num_channels_down=128, num_channels_up=128, num_channels_skip=128, filter_size_up=3, filter_size_down=3,
               upsample_mode='nearest', downsample_mode='stride', filter_skip_size=1, need_sigmoid=True, need_bias=True, pad='zero', act_fun='LeakyReLU'):
        super(AttentionUnet, self).__init__()
        input_depth = num_input_channels
        self.stage_1_skip = nn.Sequential()
        self.stage_1_skip.add(conv(input_depth, num_channels_skip, filter_skip_size, bias=need_bias, pad=pad))
        self.stage_1_skip.add(bn(num_channels_skip))
        self.stage_1_skip.add(act(act_fun))

        self.stage_1_deeper = nn.Sequential()
        self.stage_1_deeper.add(conv(input_depth, num_channels_down, filter_size_down, 2, bias=need_bias, pad=pad, downsample_mode=downsample_mode))
        self.stage_1_deeper.add(bn(num_channels_down))
        self.stage_1_deeper.add(act(act_fun))

        self.stage_1_deeper.add(conv(num_channels_down, num_channels_down, filter_size_down, bias=need_bias, pad=pad))
        self.stage_1_deeper.add(bn(num_channels_down))
        self.stage_1_deeper.add(act(act_fun))


        self.stage_2_skip = nn.Sequential()
        self.stage_2_skip.add(conv(num_channels_down, num_channels_skip, filter_skip_size, bias=need_bias, pad=pad))
        self.stage_2_skip.add(bn(num_channels_skip))
        self.stage_2_skip.add(act(act_fun))

        self.stage_2_deeper = nn.Sequential()
        self.stage_2_deeper.add(conv(num_channels_down, num_channels_down, filter_size_down, 2, bias=need_bias, pad=pad, downsample_mode=downsample_mode))
        self.stage_2_deeper.add(bn(num_channels_down))
        self.stage_2_deeper.add(act(act_fun))

        self.stage_2_deeper.add(conv(num_channels_down, num_channels_down, filter_size_down, bias=need_bias, pad=pad))
        self.stage_2_deeper.add(bn(num_channels_down))
        self.stage_2_deeper.add(act(act_fun))


        self.stage_3_skip = nn.Sequential()
        self.stage_3_skip.add(conv(num_channels_down, num_channels_skip, filter_skip_size, bias=need_bias, pad=pad))
        self.stage_3_skip.add(bn(num_channels_skip))
        self.stage_3_skip.add(act(act_fun))

        self.stage_3_deeper = nn.Sequential()
        self.stage_3_deeper.add(conv(num_channels_down, num_channels_down, filter_size_down, 2, bias=need_bias, pad=pad, downsample_mode=downsample_mode))
        self.stage_3_deeper.add(bn(num_channels_down))
        self.stage_3_deeper.add(act(act_fun))

        self.stage_3_deeper.add(conv(num_channels_down, num_channels_down, filter_size_down, bias=need_bias, pad=pad))
        self.stage_3_deeper.add(bn(num_channels_down))
        self.stage_3_deeper.add(act(act_fun))


        self.stage_4_skip = nn.Sequential()
        self.stage_4_skip.add(conv(num_channels_down, num_channels_skip, filter_skip_size, bias=need_bias, pad=pad))
        self.stage_4_skip.add(bn(num_channels_skip))
        self.stage_4_skip.add(act(act_fun))

        self.stage_4_deeper = nn.Sequential()
        self.stage_4_deeper.add(conv(num_channels_down, num_channels_down, filter_size_down, 2, bias=need_bias, pad=pad, downsample_mode=downsample_mode))
        self.stage_4_deeper.add(bn(num_channels_down))
        self.stage_4_deeper.add(act(act_fun))

        self.stage_4_deeper.add(conv(num_channels_down, num_channels_down, filter_size_down, bias=need_bias, pad=pad))
        self.stage_4_deeper.add(bn(num_channels_down))
        self.stage_4_deeper.add(act(act_fun))


        self.stage_5_skip = nn.Sequential()
        self.stage_5_skip.add(conv(num_channels_down, num_channels_skip, filter_skip_size, bias=need_bias, pad=pad))
        self.stage_5_skip.add(bn(num_channels_skip))
        self.stage_5_skip.add(act(act_fun))

        self.stage_5_deeper = nn.Sequential()
        self.stage_5_deeper.add(conv(num_channels_down, num_channels_down, filter_size_down, 2, bias=need_bias, pad=pad, downsample_mode=downsample_mode))
        self.stage_5_deeper.add(bn(num_channels_down))
        self.stage_5_deeper.add(act(act_fun))

        self.stage_5_deeper.add(conv(num_channels_down, num_channels_down, filter_size_down, bias=need_bias, pad=pad))
        self.stage_5_deeper.add(bn(num_channels_down))
        self.stage_5_deeper.add(act(act_fun))



        self.upsample_5 = nn.Sequential(
           nn.Upsample(scale_factor=2, mode='nearest')
        )
        self.upsample_4 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest')
        )
        self.upsample_3 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest')
        )
        self.upsample_2 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest')
        )
        self.upsample_1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest')
        )


        self.de_stage_5_skip = nn.Sequential()
        self.de_stage_5_skip.add(conv(256, num_channels_up, filter_size_up, 1, bias=need_bias, pad=pad))
        self.de_stage_5_skip.add(bn(num_channels_up))
        self.de_stage_5_skip.add(act(act_fun))

        self.de_stage_5_deeper = nn.Sequential()
        self.de_stage_5_deeper.add(conv(num_channels_up, num_channels_up, 1, bias=need_bias, pad=pad))
        self.de_stage_5_deeper.add(bn(num_channels_up))
        self.de_stage_5_deeper.add(act(act_fun))



        self.de_stage_4_skip = nn.Sequential()
        self.de_stage_4_skip.add(conv(256, num_channels_up, filter_size_up, 1, bias=need_bias, pad=pad))
        self.de_stage_4_skip.add(bn(num_channels_up))
        self.de_stage_4_skip.add(act(act_fun))

        self.de_stage_4_deeper = nn.Sequential()
        self.de_stage_4_deeper.add(conv(num_channels_up, num_channels_up, 1, bias=need_bias, pad=pad))
        self.de_stage_4_deeper.add(bn(num_channels_up))
        self.de_stage_4_deeper.add(act(act_fun))


        self.de_stage_3_skip = nn.Sequential()
        self.de_stage_3_skip.add(conv(256, num_channels_up, filter_size_up, 1, bias=need_bias, pad=pad))
        self.de_stage_3_skip.add(bn(num_channels_up))
        self.de_stage_3_skip.add(act(act_fun))

        self.de_stage_3_deeper = nn.Sequential()
        self.de_stage_3_deeper.add(conv(num_channels_up, num_channels_up, 1, bias=need_bias, pad=pad))
        self.de_stage_3_deeper.add(bn(num_channels_up))
        self.de_stage_3_deeper.add(act(act_fun))


        self.de_stage_2_skip = nn.Sequential()
        self.de_stage_2_skip.add(conv(256, num_channels_up, filter_size_up, 1, bias=need_bias, pad=pad))
        self.de_stage_2_skip.add(bn(num_channels_up))
        self.de_stage_2_skip.add(act(act_fun))

        self.de_stage_2_deeper = nn.Sequential()
        self.de_stage_2_deeper.add(conv(num_channels_up, num_channels_up, 1, bias=need_bias, pad=pad))
        self.de_stage_2_deeper.add(bn(num_channels_up))
        self.de_stage_2_deeper.add(act(act_fun))


        self.de_stage_1_skip = nn.Sequential()
        self.de_stage_1_skip.add(conv(256, num_channels_up, filter_size_up, 1, bias=need_bias, pad=pad))
        self.de_stage_1_skip.add(bn(num_channels_up))
        self.de_stage_1_skip.add(act(act_fun))

        self.de_stage_1_deeper = nn.Sequential()
        self.de_stage_1_deeper.add(conv(num_channels_up, num_channels_up, 1, bias=need_bias, pad=pad))
        self.de_stage_1_deeper.add(bn(num_channels_up))
        self.de_stage_1_deeper.add(act(act_fun))


        self.Attentiongate1 = AttentionBlock(128, 128, 128)
        self.Attentiongate2 = AttentionBlock(128, 128, 128)
        self.Attentiongate3 = AttentionBlock(128, 128, 128)
        self.Attentiongate4 = AttentionBlock(128, 128, 128)
        self.Attentiongate5 = AttentionBlock(128, 128, 128)

        self.final = nn.Sequential()
        self.final.add(conv(num_channels_up, num_output_channels, 1, bias=need_bias, pad=pad))
        self.final.add(nn.Sigmoid())


    def forward(self, x):

        # encorder
        stage_1_skip = self.stage_1_skip(x)
        stage_1_deeper = self.stage_1_deeper(x)

        stage_2_skip = self.stage_2_skip(stage_1_deeper)
        stage_2_deeper = self.stage_2_deeper(stage_2_skip)

        stage_3_skip = self.stage_3_skip(stage_2_deeper)
        stage_3_deeper = self.stage_3_deeper(stage_3_skip)

        stage_4_skip = self.stage_4_skip(stage_3_deeper)
        stage_4_deeper = self.stage_4_deeper(stage_4_skip)

        stage_5_skip = self.stage_5_skip(stage_4_deeper)
        stage_5_deeper = self.stage_5_deeper(stage_5_skip)

        #decorder
        up_5 = self.upsample_5(stage_5_deeper)
        up_5 = redu(up_5, stage_5_skip)
        stage_5 = self.Attentiongate5(up_5, stage_5_skip)
        up_5_conv_skip = self.de_stage_5_skip(torch.cat([up_5, stage_5], dim=1))
        # up_5_conv_skip = self.de_stage_5_skip(stage_5)
        up_5_conv_deeper = self.de_stage_5_deeper(up_5_conv_skip)

        up_4 = self.upsample_4(up_5_conv_deeper)
        up_4 = redu(up_4, stage_4_skip)
        stage_4 = self.Attentiongate4(up_4, stage_4_skip)
        up_4_conv_skip = self.de_stage_4_skip(torch.cat([up_4, stage_4], dim=1))
        # up_4_conv_skip = self.de_stage_4_skip(stage_4)
        up_4_conv_deeper = self.de_stage_4_deeper(up_4_conv_skip)

        up_3 = self.upsample_3(up_4_conv_deeper)
        up_3 = redu(up_3, stage_3_skip)
        stage_3 = self.Attentiongate3(up_3, stage_3_skip)
        up_3_conv_skip = self.de_stage_3_skip(torch.cat([up_3, stage_3], dim=1))
        # up_3_conv_skip = self.de_stage_3_skip(stage_3)
        up_3_conv_deeper = self.de_stage_3_deeper(up_3_conv_skip)

        up_2 = self.upsample_2(up_3_conv_deeper)
        up_2 = redu(up_2, stage_2_skip)
        stage_2 = self.Attentiongate2(up_2, stage_2_skip)
        up_2_conv_skip = self.de_stage_2_skip(torch.cat([up_2, stage_2], dim=1))
        # up_2_conv_skip = self.de_stage_2_skip(stage_2)
        up_2_conv_deeper = self.de_stage_2_deeper(up_2_conv_skip)

        up_1 = self.upsample_1(up_2_conv_deeper)
        up_1 = redu(up_1, stage_1_skip)
        stage_1 = self.Attentiongate1(up_1, stage_1_skip)
        up_1_conv_skip = self.de_stage_1_skip(torch.cat([up_1, stage_1], dim=1))
        # up_1_conv_skip = self.de_stage_1_skip(stage_1)
        up_1_conv_deeper = self.de_stage_1_deeper(up_1_conv_skip)

        output = self.final(up_1_conv_deeper)

        return output