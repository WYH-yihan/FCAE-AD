clear;
load("./data/abu-beach-1.mat");
load("./loop2/Beach_detection1.mat");
%% 引导滤波
iter=1;
w=9;  %windows
[sci,sct]=SPWCF(data,iter,w);   %calculate guided map %detection
I = sci;
figure;
imshow(I);
%I = Mo;
p = detection;
r = 4;
eps = 0.5;  %0.8^2; 
Rr = guidedfilter(I, p, r, eps);
Re = hyperNormalize(Rr);
figure;
imshow(Re);
ttt=AUC(map(:),Re(:));
